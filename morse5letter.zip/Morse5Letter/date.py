import date_calculator


#start_date = "2023-09-25"
#days_to_add = 500

#future_date = date_calculator.calculate_future_date(start_date, days_to_add)
#print(f"Future date: {future_date}")

from date_calculator import calculate_days_between_dates
from datetime import datetime

today_date = datetime.today().date()

date1_str = "2023-01-01"
date2_str = today_date_string = today_date.strftime('%Y-%m-%d')

days_between = calculate_days_between_dates(date1_str, date2_str)
print(f"Number of days between {date1_str} and {date2_str}: {days_between} days")

