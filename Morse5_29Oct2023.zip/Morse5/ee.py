1#1/encode message to index numbers from dictionary
#2/decode number string to words from dictionary
import string
#import onetimepad

def decimal_to_modulo26(decimal_number):
    if not isinstance(decimal_number, int):
        raise ValueError("Input must be an integer")

    if decimal_number < 0:
        raise ValueError("Input must be a non-negative integer")

    if decimal_number == 0:
        return 'A'

    modulo26_result = ""

    while decimal_number > 0:
        remainder = (decimal_number - 1) % 26  # Subtract 1 to map 1 to 'A', 2 t
        modulo26_result = chr(ord('A') + remainder) + modulo26_result
        decimal_number = (decimal_number - 1) // 26

    return modulo26_result

def modulo26_to_decimal(modulo26_number):
    if not modulo26_number:
        return 0

   
    decimal_result = 0
    position_multiplier = 1

    for char in reversed(modulo26_number):
        decimal_result += (ord(char) - ord('A') + 1) * position_multiplier
        position_multiplier *= 26

    return decimal_result


f=open("dict.txt","r")

#dict is a list of words
d=f.read()
dict=d.splitlines()
blank_list = string.punctuation
#print(string.punctuation)

#not working
#    for i in len(blank_list) :
#        blank_list[i]=' '
        

#enc_dec = input("Encode 1, Decode 2 : ")
def encoding (msg_string):
#if (enc_dec == '1'):
#    print('encoding')
#    msg_string = input("Type your msg : ")
    msg_string = msg_string.translate(str.maketrans(string.punctuation, blank_list, string.punctuation))
    msg_string = msg_string.lower()
    msg = msg_string.split()

    msg_ab_list = []
    for word in msg:
        if word in dict:
            i=dict.index(word)
            i26=decimal_to_modulo26(i)
#           print(i,"\t",i26,"\t", word)
            msg_ab_list.append(i26)

#    print(msg_ab_list)
    cypher_op=''
    for i in msg_ab_list:
       cypher_op=cypher_op+ str(i)
       cypher_op=cypher_op+ '0'

#    print(cypher_op)   
    return cypher_op
    
def decoding (ab_string) :
#   if (enc_dec == '2'):
#   print('decoding') 
#   ab_string = input("Type your encoded_msg : ")
    ab_string = ab_string.upper()
    ab_string = ab_string.replace('0',' ')
    #print(abstring)
    ab_list = ab_string.split()
#    print(ab_list)
    
    word_num =[]
    for ab in ab_list:
        i=modulo26_to_decimal(ab)
        word=dict[i]
 #      print(i,"\t", word)
        word_num.append(word)

#    print(word_num)
    return word_num

def one_time_pad_encrypt(message, key, alphabet):
    if  len(message) >  len(key):
        raise ValueError("Message must be shorter than or equal to length of key")

    encrypted_message = []
    for i in range(len(message)):
        message_char = message[i]
        key_char = key[i]
        message_index = alphabet.index(message_char)
        key_index = alphabet.index(key_char)
        encrypted_char = alphabet[(message_index + key_index) % len(alphabet)]
        encrypted_message.append(encrypted_char)

    return ''.join(encrypted_message)
#    return encrypted_message

def one_time_pad_decrypt(encrypted_message, key, alphabet):
    if len(encrypted_message) > len(key):
        raise ValueError("Message must be shorter than or equal to length of key")

    decrypted_message = []
    for i in range(len(encrypted_message)):
        encrypted_char = encrypted_message[i]
        key_char = key[i]
        encrypted_index = alphabet.index(encrypted_char)
        key_index = alphabet.index(key_char)
        decrypted_char = alphabet[(encrypted_index - key_index) % len(alphabet)]
        decrypted_message.append(decrypted_char)

    return ''.join(decrypted_message)

import key

# Example usage:
#alphabet = "0ABCDEFGHIJKLMNOPQRSTUVWXYZ"  # You can customize the alphabet as needed
# message = input("msg: ")
# key = input("key: ")

# encrypted_message = one_time_pad_encrypt(message, key, alphabet)
# print("Encrypted message:", encrypted_message)

# decrypted_message = one_time_pad_decrypt(encrypted_message, key, alphabet)
# print("Decrypted message:", decrypted_message)

import text_divider

if  __name__ == "__main__":
    alphabet = "0ABCDEFGHIJKLMNOPQRSTUVWXYZ" 
    message = input("type message : ")
    encoded_msg = encoding(message)
    pad = len(encoded_msg) % 5 
    if pad != 0 :
        pad = 5 - pad
        encoded_msg = encoded_msg + pad * '0'
    print("encoded : ", encoded_msg)
    key = key.otp_key()
    print("key : \n\n", key, "\n\n")
    encrypted_msg = one_time_pad_encrypt(encoded_msg, key, alphabet)
    divided_encrypted_msg = text_divider.formated_5_letter(encrypted_msg)
    print("encrypted : \n\n", divided_encrypted_msg, "\n\n")
#   print('\n',encrypted_msg,'\n')
#   decrypted_msg = one_time_pad_decrypt(encrypted_msg, key, alphabet)
#   print("decrypted : ", decrypted_msg)


