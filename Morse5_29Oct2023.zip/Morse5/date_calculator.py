from datetime import datetime, timedelta

def calculate_future_date(start_date_str, days_to_add):
    try:
        # Parse the input start_date string to a datetime object
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d')

        # Calculate the future date by adding the specified number of days
        future_date = start_date + timedelta(days=days_to_add)

        # Format the future date as a string in the same format as the input
        future_date_str = future_date.strftime('%Y-%m-%d')

        return future_date_str

    except ValueError:
        return "Invalid date format. Please use 'YYYY-MM-DD'."

from datetime import datetime

def calculate_days_between_dates(date1_str, date2_str):
    try:
        # Parse the input date strings into datetime objects
        date1 = datetime.strptime(date1_str, '%Y-%m-%d')
        date2 = datetime.strptime(date2_str, '%Y-%m-%d')
        
        # Calculate the difference between the two dates
        delta = abs(date2 - date1)
        
        # Extract the number of days as an integer
        days_between = delta.days
        
        return days_between
    except ValueError as e:
        return str(e)

if __name__ == "__main__":
    date1_str = input("Enter the first date (YYYY-MM-DD): ")
    date2_str = input("Enter the second date (YYYY-MM-DD): ")
    
    days_between = calculate_days_between_dates(date1_str, date2_str)
    
    if isinstance(days_between, int):
        print(f"Number of days between {date1_str} and {date2_str}: {days_between} days")
    else:
        print(f"Error: {days_between}")

if __name__ == "__main__":
    start_date_str = input("Enter the starting date (YYYY-MM-DD): ")
    days_to_add = int(input("Enter the number of days to add: "))

    future_date_str = calculate_future_date(start_date_str, days_to_add)
    print(f"Future date: {future_date_str}")

