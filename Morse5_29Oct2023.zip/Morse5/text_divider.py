def divide_text_into_groups(text):
    text = ''.join(filter(str.isalnum, text))  # Remove non-alphanumeric characters
    groups = [text[i:i + 5] for i in range(0, len(text), 5)]
    return groups

def groups_with_line_numbers(groups):
    divided_text =''
    for i, group in enumerate(groups, start=1):
        divided_text = divided_text + group + ' '
#       print(f"{group}", end=' ')

        if i % 5 == 0:
            divided_text = divided_text + '\n' 
#            print()
    return(divided_text)

def formated_5_letter(text):
    return groups_with_line_numbers(divide_text_into_groups(text))

#if __name__ == "__main__":
#    text = input("Enter the text string: ")
    
#    groups = divide_text_into_groups(text)
    
#    print("\n5-letter groups with line numbers (5 groups per line):\n")
#    print_groups_with_line_numbers(groups)
#    print("\n")
