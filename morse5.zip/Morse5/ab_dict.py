1#1/encode message to index numbers from dictionary
#2/decode number string to words from dictionary
import string

def decimal_to_modulo26(decimal_number):
    if not isinstance(decimal_number, int):
        raise ValueError("Input must be an integer")

    if decimal_number < 0:
        raise ValueError("Input must be a non-negative integer")

    if decimal_number == 0:
        return 'A'

    modulo26_result = ""

    while decimal_number > 0:
        remainder = (decimal_number - 1) % 26  # Subtract 1 to map 1 to 'A', 2 t
        modulo26_result = chr(ord('A') + remainder) + modulo26_result
        decimal_number = (decimal_number - 1) // 26

    return modulo26_result

def modulo26_to_decimal(modulo26_number):
    if not modulo26_number:
        return 0

   
    decimal_result = 0
    position_multiplier = 1

    for char in reversed(modulo26_number):
        decimal_result += (ord(char) - ord('A') + 1) * position_multiplier
        position_multiplier *= 26

    return decimal_result


f=open("dict.txt","r")

#dict is a list of words
d=f.read()
dict=d.splitlines()
blank_list = string.punctuation
#print(string.punctuation)

#not working
#    for i in len(blank_list) :
#        blank_list[i]=' '
        

enc_dec = input("Encode 1, Decode 2 : ")

if (enc_dec == '1'):
    print('encoding')
    msg_string = input("Type your msg : ")
    msg_string = msg_string.translate(str.maketrans(string.punctuation, blank_list, string.punctuation))
    msg_string = msg_string.lower()
    msg = msg_string.split()

    msg_ab_list = []
    for word in msg:
        if word in dict:
            i=dict.index(word)
            i26=decimal_to_modulo26(i)
            print(i,"\t",i26,"\t", word)
            msg_ab_list.append(i26)

    print(msg_ab_list)
    cypher_op=''
    for i in msg_ab_list:
       cypher_op=cypher_op+ str(i)
       cypher_op=cypher_op+ '0'

    print(cypher_op)   

if (enc_dec == '2'):
    print('decoding') 
    ab_string = input("Type your encoded_msg : ")
    ab_string = ab_string.upper()
    ab_string = ab_string.replace('0',' ')
    #print(abstring)
    ab_list = ab_string.split()
    print(ab_list)
    
    word_num =[]
    for ab in ab_list:
        i=modulo26_to_decimal(ab)
        word=dict[i]
        print(i,"\t", word)
        word_num.append(word)

    print(word_num)


