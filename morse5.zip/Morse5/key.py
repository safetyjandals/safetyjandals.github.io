
import date_calculator
#import print_line_from_file

#start_date = "2023-09-25"
#days_to_add = 500

#future_date = date_calculator.calculate_future_date(start_date, days_to_add)
#print(f"Future date: {future_date}")


from date_calculator import calculate_days_between_dates
from datetime import datetime

today_date = datetime.today().date()

date1_str = "2023-01-01"
#date2_str = today_date_string = today_date.strftime('%Y-%m-%d')
date2_str = input('%YYYY-%mm-%dd : ')

days_between = calculate_days_between_dates(date1_str, date2_str)
#print(f"Number of days between {date1_str} and {date2_str}: {days_between} days")

def line_by_number(file_name, line_number):
    try:
        with open(file_name, 'r') as file:
            lines = file.readlines()
            if 1 <= line_number <= len(lines):
                line_to_print = lines[line_number - 1]
#                print(f"Line {line_number}: {line_to_print.strip()}")
#                print(f"{line_to_print.strip()}")
                key = line_to_print.strip()
            else:
                print(f"Line number {line_number} is out of range for the file.")
    except FileNotFoundError:
        print(f"File not found: {file_name}")
    except Exception as e:
        print(f"An error occurred: {str(e)}")
    return key
    



#if __name__ == "__main__":
#    file_name = input("Enter the file name: ")
#    line_number = int(input("Enter the line number: "))
#    line_number = days_between
def otp_key():
    line_number = days_between
    line = line_by_number("keys.txt", line_number)
    b = "0123456789() "
    for char in b:
        line = line.replace(char, "")
#    print(line)
    return(line)
    
#if __name__ == "__main__":
#    line_number = days_between
#    otp_key()



